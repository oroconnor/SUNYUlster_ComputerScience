//Owen O'Connor
//CSC 201
//Assignment 2

package militarytimeconverter;
/** 
 *  @author owenoconnor
 *  @since 08/27/21
 *  Custom exception for militarytimeconverter package
 */
public class NumberNotInRange extends Exception {

}
