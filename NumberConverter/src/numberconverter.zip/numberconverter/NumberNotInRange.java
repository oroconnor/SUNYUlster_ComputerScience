package numberconverter;

public class NumberNotInRange extends Exception {


	}
