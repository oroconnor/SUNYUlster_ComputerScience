//Owen O'Connor - CSC 180 - assignment #8

package marathon;
/** exception thrown when there would be a negative race duration for Marathon.java
 *  @author owenoconnor
 *  @since 03/25/21
 */
public class NegativeRaceTime extends Exception {

}
