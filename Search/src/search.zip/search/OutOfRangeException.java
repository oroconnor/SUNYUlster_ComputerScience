//Owen O'Connor - CSC 180 - assignment #9
package search;
/** exception thrown when choice is out of range Search.java
 *  @author owenoconnor
 *  @since 03/25/21
 */
public class OutOfRangeException extends Exception {

}
